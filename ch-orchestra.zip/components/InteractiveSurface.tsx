
import React, { useState, useRef, useCallback, useEffect } from 'react';
import { Point, TraceParticle } from '../types';
import audioService from '../services/AudioService';

const MAX_TRAIL_PARTICLES = 50;
const PARTICLE_MAX_AGE = 1500; // milliseconds
const PARTICLE_BASE_SIZE = 20; // px

const InteractiveSurface: React.FC = () => {
  const [isInteracting, setIsInteracting] = useState<boolean>(false);
  const [cursorPos, setCursorPos] = useState<Point | null>(null);
  const [trailParticles, setTrailParticles] = useState<TraceParticle[]>([]);
  const [audioInitialized, setAudioInitialized] = useState<boolean>(false);
  const [showInstructions, setShowInstructions] = useState<boolean>(true);

  const surfaceRef = useRef<HTMLDivElement>(null);
  const lastPosRef = useRef<Point | null>(null);
  const lastTimeRef = useRef<number>(0);

  const initAudio = useCallback(async () => {
    if (!audioInitialized) {
      await audioService.init();
      setAudioInitialized(true);
      setShowInstructions(false); // Hide instructions after first interaction
    }
  }, [audioInitialized]);

  const addTrailParticle = useCallback((point: Point) => {
    setTrailParticles(prev => {
      const newParticle: TraceParticle = {
        id: `${Date.now()}-${Math.random()}`,
        x: point.x,
        y: point.y,
        startTime: Date.now(),
        maxAge: PARTICLE_MAX_AGE * (0.8 + Math.random() * 0.4), // Vary age slightly
        baseSize: PARTICLE_BASE_SIZE * (0.7 + Math.random() * 0.6), // Vary size slightly
      };
      const updated = [...prev, newParticle];
      return updated.length > MAX_TRAIL_PARTICLES ? updated.slice(updated.length - MAX_TRAIL_PARTICLES) : updated;
    });
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      const now = Date.now();
      setTrailParticles(prev => prev.filter(p => now - p.startTime < p.maxAge));
    }, 100); // Cleanup interval
    return () => clearInterval(interval);
  }, []);

  const handleInteractionStart = useCallback((clientX: number, clientY: number) => {
    initAudio(); // Ensure audio is ready
    setIsInteracting(true);
    if (!surfaceRef.current) return;
    const rect = surfaceRef.current.getBoundingClientRect();
    const x = clientX - rect.left;
    const y = clientY - rect.top;
    setCursorPos({ x, y });
    lastPosRef.current = { x, y };
    lastTimeRef.current = performance.now();

    const audioParams = audioService.calculateAudioParams(x, y, rect.width, rect.height, 0);
    audioService.startSound(audioParams);
    addTrailParticle({ x, y });
  }, [initAudio, addTrailParticle]);

  const handleInteractionMove = useCallback((clientX: number, clientY: number) => {
    if (!isInteracting || !surfaceRef.current) return;
    
    const rect = surfaceRef.current.getBoundingClientRect();
    const x = clientX - rect.left;
    const y = clientY - rect.top;
    setCursorPos({ x, y });

    let speed = 0;
    const currentTime = performance.now();
    if (lastPosRef.current && lastTimeRef.current > 0) {
        const dx = x - lastPosRef.current.x;
        const dy = y - lastPosRef.current.y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        const timeDelta = currentTime - lastTimeRef.current;
        if (timeDelta > 0) {
            speed = dist / (timeDelta / 16); // Pixels per frame (approx)
        }
    }
    lastPosRef.current = { x, y };
    lastTimeRef.current = currentTime;

    const audioParams = audioService.calculateAudioParams(x, y, rect.width, rect.height, speed);
    audioService.updateSound(audioParams);
    addTrailParticle({ x, y });
  }, [isInteracting, addTrailParticle]);

  const handleInteractionEnd = useCallback(() => {
    setIsInteracting(false);
    // Keep cursor position to show the circle at the last point, or hide it:
    // setCursorPos(null); 
    audioService.stopSound();
    lastPosRef.current = null;
    lastTimeRef.current = 0;
  }, []);

  // Mouse events
  const onMouseDown = (e: React.MouseEvent<HTMLDivElement>) => handleInteractionStart(e.clientX, e.clientY);
  const onMouseMove = (e: React.MouseEvent<HTMLDivElement>) => handleInteractionMove(e.clientX, e.clientY);
  const onMouseUp = () => handleInteractionEnd();
  const onMouseLeave = () => { // Optional: stop sound if mouse leaves area while pressed
    if(isInteracting) handleInteractionEnd();
  }

  // Touch events
  const onTouchStart = (e: React.TouchEvent<HTMLDivElement>) => {
    if (e.touches.length > 0) {
      handleInteractionStart(e.touches[0].clientX, e.touches[0].clientY);
    }
  };
  const onTouchMove = (e: React.TouchEvent<HTMLDivElement>) => {
    if (e.touches.length > 0) {
      handleInteractionMove(e.touches[0].clientX, e.touches[0].clientY);
    }
  };
  const onTouchEnd = () => handleInteractionEnd();

  return (
    <div
      ref={surfaceRef}
      className="w-full h-full cursor-none relative overflow-hidden touch-none"
      onMouseDown={onMouseDown}
      onMouseMove={onMouseMove}
      onMouseUp={onMouseUp}
      onMouseLeave={onMouseLeave}
      onTouchStart={onTouchStart}
      onTouchMove={onTouchMove}
      onTouchEnd={onTouchEnd}
    >
      {showInstructions && !audioInitialized && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <p className="text-amber-200 text-2xl md:text-4xl font-serif animate-pulse">
            Touch or Click to Begin Your Symphony
          </p>
        </div>
      )}

      {/* Render Trail Particles */}
      {trailParticles.map(p => {
        const age = Date.now() - p.startTime;
        const lifeRatio = Math.max(0, 1 - age / p.maxAge);
        const currentOpacity = lifeRatio * 0.7; // Max opacity 0.7
        const currentSize = p.baseSize * lifeRatio * (isInteracting ? 1 : 0.5); // Smaller when not interacting actively

        if (currentSize < 1) return null; // Don't render if too small

        return (
          <div
            key={p.id}
            className={`absolute rounded-full bg-pink-400/80 pointer-events-none transition-opacity ease-out`}
            style={{
              left: `${p.x - currentSize / 2}px`,
              top: `${p.y - currentSize / 2}px`,
              width: `${currentSize}px`,
              height: `${currentSize}px`,
              opacity: currentOpacity,
              transform: `scale(${lifeRatio})`,
              filter: `blur(${ (1-lifeRatio) * 5}px)`, // More blur as it fades
              boxShadow: `0 0 ${currentSize * 0.5}px ${currentSize * 0.25}px rgba(252, 165, 165, ${currentOpacity * 0.7})` // Dynamic shadow based on size and opacity
            }}
          />
        );
      })}

      {/* Render Glowing Cursor/Touch Circle */}
      {isInteracting && cursorPos && (
        <div
          className="absolute rounded-full bg-rose-300 pointer-events-none"
          style={{
            left: `${cursorPos.x - 20}px`, // Centered: 40px width/height
            top: `${cursorPos.y - 20}px`,
            width: '40px',
            height: '40px',
            boxShadow: '0 0 25px 12px rgba(251, 146, 156, 0.6), 0 0 40px 20px rgba(251, 146, 156, 0.4)', // Rose-300 equivalent
            transform: 'translateZ(0)', // Promote to own layer for smoother animation
            transition: 'transform 0.05s ease-out, box-shadow 0.05s ease-out', // Smooth size/shadow changes
          }}
        />
      )}
    </div>
  );
};

export default InteractiveSurface;
    