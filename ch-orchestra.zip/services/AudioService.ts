import { AudioParameters, InstrumentStyle } from '../types';

const MIN_FREQ = 80; // Hz (approx E2)
const MAX_FREQ = 1200; // Hz (approx D6)
const MAX_VOLUME = 0.3; // Max master gain to avoid clipping
const MIN_FILTER_FREQ = 200;
const MAX_FILTER_FREQ = 8000;

class AudioService {
  private audioCtx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private filter: BiquadFilterNode | null = null;

  private osc1: OscillatorNode | null = null;
  private osc1Gain: GainNode | null = null;
  
  private osc2: OscillatorNode | null = null;
  private osc2Gain: GainNode | null = null;

  private osc3: OscillatorNode | null = null;
  private osc3Gain: GainNode | null = null;

  private lfo: OscillatorNode | null = null; // For rhythmic effects
  private lfoGain: GainNode | null = null;   // Controls LFO depth

  private isPlaying: boolean = false;
  private currentStyle: InstrumentStyle = InstrumentStyle.ETHEREAL_PAD;
  private lastParams: AudioParameters | null = null;

  public async init(): Promise<void> {
    if (!this.audioCtx) {
      this.audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      
      this.masterGain = this.audioCtx.createGain();
      this.masterGain.gain.setValueAtTime(MAX_VOLUME, this.audioCtx.currentTime);
      
      this.filter = this.audioCtx.createBiquadFilter();
      this.filter.type = "lowpass";
      this.filter.frequency.setValueAtTime(MAX_FILTER_FREQ, this.audioCtx.currentTime);
      this.filter.Q.setValueAtTime(1, this.audioCtx.currentTime);

      this.filter.connect(this.masterGain);
      this.masterGain.connect(this.audioCtx.destination);
    }
    if (this.audioCtx.state === 'suspended') {
      await this.audioCtx.resume();
    }
  }

  private ensureAudioContext(): AudioContext {
    if (!this.audioCtx || !this.masterGain || !this.filter) {
      throw new Error("AudioContext not initialized. Call init() first.");
    }
    if (this.audioCtx.state === 'suspended') {
        // This should ideally be handled by user interaction triggering init if suspended.
        // For now, we'll log and proceed; sound might not play until resumed.
        console.warn("AudioContext is suspended. User interaction may be needed.");
    }
    return this.audioCtx;
  }

  public setStyle(newStyle: InstrumentStyle): void {
    if (this.currentStyle === newStyle) return;
    this.currentStyle = newStyle;

    if (this.isPlaying && this.lastParams) {
      const currentParams = { ...this.lastParams };
      // Brief internal stop, don't update global isPlaying state or clear lastParams yet
      this.stopSoundInternal(0.01, false); 
      this.startSound(currentParams); // Restart with new style
    }
  }

  private cleanupOscillators(): void {
    const now = this.audioCtx?.currentTime ?? performance.now() / 1000;
    [this.osc1, this.osc2, this.osc3, this.lfo].forEach(osc => {
      if (osc) {
        try { osc.stop(now); } catch (e) { /* already stopped */ }
        osc.disconnect();
      }
    });
    [this.osc1Gain, this.osc2Gain, this.osc3Gain, this.lfoGain].forEach(gain => {
      if (gain) gain.disconnect();
    });
    this.osc1 = this.osc2 = this.osc3 = this.lfo = null;
    this.osc1Gain = this.osc2Gain = this.osc3Gain = this.lfoGain = null;
  }

  public startSound(params: AudioParameters): void {
    const audioCtx = this.ensureAudioContext();
    this.lastParams = { ...params };

    // Clean up any previous oscillators before setting up new ones for the style
    // This is crucial for style transitions and ensuring a clean audio graph
    this.cleanupOscillators();

    const now = audioCtx.currentTime;

    switch (this.currentStyle) {
      case InstrumentStyle.ETHEREAL_PAD:
        this.setupEtherealPad(audioCtx, params, now);
        break;
      case InstrumentStyle.SYNTH_LEAD:
        this.setupSynthLead(audioCtx, params, now);
        break;
      case InstrumentStyle.PERCUSSIVE_PLUCK:
        this.setupPercussivePluck(audioCtx, params, now);
        break;
    }
    this.isPlaying = true;
  }

  private setupEtherealPad(audioCtx: AudioContext, params: AudioParameters, now: number): void {
    const attackTime = 0.1;
    // Osc1
    this.osc1 = audioCtx.createOscillator();
    this.osc1.type = 'triangle';
    this.osc1.frequency.setValueAtTime(params.frequency, now);
    this.osc1Gain = audioCtx.createGain();
    this.osc1Gain.gain.setValueAtTime(0, now);
    this.osc1Gain.gain.linearRampToValueAtTime(params.volume * 0.7, now + attackTime);
    this.osc1.connect(this.osc1Gain).connect(this.filter!);
    this.osc1.start(now);

    // Osc2 (Harmony)
    this.osc2 = audioCtx.createOscillator();
    this.osc2.type = 'sine';
    this.osc2.frequency.setValueAtTime(params.frequency * (params.harmonyVolume && params.harmonyVolume > 0.5 ? 1.5 : 2), now);
    this.osc2Gain = audioCtx.createGain();
    this.osc2Gain.gain.setValueAtTime(0, now);
    this.osc2Gain.gain.linearRampToValueAtTime((params.harmonyVolume ?? params.volume) * 0.4, now + attackTime);
    this.osc2.connect(this.osc2Gain).connect(this.filter!);
    this.osc2.start(now);
    
    // Osc3 (Sub Bass)
    this.osc3 = audioCtx.createOscillator();
    this.osc3.type = 'sine';
    this.osc3.frequency.setValueAtTime(params.frequency * 0.5, now);
    this.osc3Gain = audioCtx.createGain();
    this.osc3Gain.gain.setValueAtTime(0, now);
    this.osc3Gain.gain.linearRampToValueAtTime(params.volume * 0.3, now + attackTime);
    this.osc3.connect(this.osc3Gain).connect(this.filter!);
    this.osc3.start(now);
  }

  private setupSynthLead(audioCtx: AudioContext, params: AudioParameters, now: number): void {
    const attackTime = 0.02;
    // Osc1
    this.osc1 = audioCtx.createOscillator();
    this.osc1.type = 'sawtooth';
    this.osc1.frequency.setValueAtTime(params.frequency, now);
    this.osc1Gain = audioCtx.createGain();
    this.osc1Gain.gain.setValueAtTime(0, now);
    this.osc1Gain.gain.linearRampToValueAtTime(params.volume * 0.6, now + attackTime);
    this.osc1.connect(this.osc1Gain).connect(this.filter!);
    this.osc1.start(now);

    // Osc2 (Harmony - Square, detuned for thickness)
    this.osc2 = audioCtx.createOscillator();
    this.osc2.type = 'square';
    this.osc2.frequency.setValueAtTime(params.frequency * 1.005 * (params.harmonyVolume && params.harmonyVolume > 0.6 ? 1.5 : 0.5), now); // Detuned 5th or sub octave
    this.osc2Gain = audioCtx.createGain();
    this.osc2Gain.gain.setValueAtTime(0, now);
    this.osc2Gain.gain.linearRampToValueAtTime((params.harmonyVolume ?? params.volume) * 0.3, now + attackTime);
    this.osc2.connect(this.osc2Gain).connect(this.filter!);
    this.osc2.start(now);

    // LFO for rhythmic pulse on sub-bass (osc3)
    this.osc3 = audioCtx.createOscillator(); // Sub-bass carrier
    this.osc3.type = 'sine';
    this.osc3.frequency.setValueAtTime(params.frequency * 0.5, now);
    this.osc3Gain = audioCtx.createGain(); // This gain will be modulated
    this.osc3Gain.gain.setValueAtTime(0, now); // Start at 0, LFO will bring it up
    this.osc3.connect(this.osc3Gain).connect(this.filter!);
    this.osc3.start(now);

    this.lfo = audioCtx.createOscillator();
    this.lfo.type = 'sine'; // Smooth pulse
    this.lfo.frequency.setValueAtTime(4, now); // 4Hz pulse (adjust for desired beat)
    this.lfoGain = audioCtx.createGain(); // LFO depth
    this.lfoGain.gain.setValueAtTime(params.volume * 0.4, now); // LFO modulates up to this level
    this.lfo.connect(this.lfoGain).connect(this.osc3Gain.gain); // LFO controls gain of osc3
    this.lfo.start(now);
  }

  private setupPercussivePluck(audioCtx: AudioContext, params: AudioParameters, now: number): void {
    const attackTime = 0.005;
    const decayTime = 0.15;
    const sustainLevel = 0.05;
    // Osc1
    this.osc1 = audioCtx.createOscillator();
    this.osc1.type = 'triangle';
    this.osc1.frequency.setValueAtTime(params.frequency, now);
    this.osc1Gain = audioCtx.createGain();
    this.osc1Gain.gain.setValueAtTime(0, now);
    this.osc1Gain.gain.linearRampToValueAtTime(params.volume * 0.8, now + attackTime);
    this.osc1Gain.gain.setTargetAtTime(sustainLevel * params.volume, now + attackTime, decayTime / 3); // Exponential decay
    this.osc1.connect(this.osc1Gain).connect(this.filter!);
    this.osc1.start(now);

    // Osc2 (Harmony - Higher octave pluck)
    this.osc2 = audioCtx.createOscillator();
    this.osc2.type = 'sine';
    this.osc2.frequency.setValueAtTime(params.frequency * 2, now);
    this.osc2Gain = audioCtx.createGain();
    this.osc2Gain.gain.setValueAtTime(0, now);
    this.osc2Gain.gain.linearRampToValueAtTime((params.harmonyVolume ?? params.volume) * 0.5, now + attackTime);
    this.osc2Gain.gain.setTargetAtTime(sustainLevel * (params.harmonyVolume ?? params.volume) * 0.2, now + attackTime, decayTime / 2.5);
    this.osc2.connect(this.osc2Gain).connect(this.filter!);
    this.osc2.start(now);
  }


  public updateSound(params: AudioParameters): void {
    if (!this.isPlaying || !this.audioCtx) return;
    this.lastParams = { ...params };
    const now = this.audioCtx.currentTime;
    
    // General ramp time, can be overridden by style updates
    const rampTime = 0.05; 

    switch (this.currentStyle) {
        case InstrumentStyle.ETHEREAL_PAD:
            this.updateEtherealPad(params, now, rampTime);
            break;
        case InstrumentStyle.SYNTH_LEAD:
            this.updateSynthLead(params, now, rampTime);
            break;
        case InstrumentStyle.PERCUSSIVE_PLUCK:
            this.updatePercussivePluck(params, now, rampTime);
            break;
    }

    // Common filter update
    if (params.filterCutoff && this.filter) {
      const targetFilterFreq = Math.max(MIN_FILTER_FREQ, Math.min(MAX_FILTER_FREQ, params.filterCutoff));
      this.filter.frequency.linearRampToValueAtTime(targetFilterFreq, now + rampTime);
    }
  }

  private updateEtherealPad(params: AudioParameters, now: number, rampTime: number): void {
    if(this.osc1) this.osc1.frequency.linearRampToValueAtTime(params.frequency, now + rampTime);
    if(this.osc1Gain) this.osc1Gain.gain.linearRampToValueAtTime(params.volume * 0.7, now + rampTime);
    
    if(this.osc2) this.osc2.frequency.linearRampToValueAtTime(params.frequency * (params.harmonyVolume && params.harmonyVolume > 0.5 ? 1.5 : 2), now + rampTime);
    if(this.osc2Gain) this.osc2Gain.gain.linearRampToValueAtTime((params.harmonyVolume ?? params.volume) * 0.4, now + rampTime);

    if(this.osc3) this.osc3.frequency.linearRampToValueAtTime(params.frequency * 0.5, now + rampTime);
    if(this.osc3Gain) this.osc3Gain.gain.linearRampToValueAtTime(params.volume * 0.3, now + rampTime);
  }

  private updateSynthLead(params: AudioParameters, now: number, rampTime: number): void {
    if(this.osc1) this.osc1.frequency.linearRampToValueAtTime(params.frequency, now + rampTime);
    if(this.osc1Gain) this.osc1Gain.gain.linearRampToValueAtTime(params.volume * 0.6, now + rampTime);

    if(this.osc2) this.osc2.frequency.linearRampToValueAtTime(params.frequency * 1.005 * (params.harmonyVolume && params.harmonyVolume > 0.6 ? 1.5 : 0.5), now + rampTime);
    if(this.osc2Gain) this.osc2Gain.gain.linearRampToValueAtTime((params.harmonyVolume ?? params.volume) * 0.3, now + rampTime);

    if(this.osc3) this.osc3.frequency.linearRampToValueAtTime(params.frequency * 0.5, now + rampTime);
    // LFO gain (depth) can also be modulated by master volume
    if(this.lfoGain) this.lfoGain.gain.linearRampToValueAtTime(params.volume * 0.4, now + rampTime);
    // Filter Q could be higher for synth lead
    if(this.filter) this.filter.Q.linearRampToValueAtTime(3, now + rampTime); 
  }

  private updatePercussivePluck(params: AudioParameters, now: number, rampTime: number): void {
    // For plucks, re-triggering the envelope on significant changes might be desired
    // For now, just adjust frequency and overall amplitude target of the decay.
    const attackTime = 0.005; // very short for re-articulation feel
    const decayTime = 0.15;
    const sustainLevel = 0.05;

    if(this.osc1) this.osc1.frequency.linearRampToValueAtTime(params.frequency, now + rampTime);
    if(this.osc1Gain) {
        this.osc1Gain.gain.cancelScheduledValues(now);
        this.osc1Gain.gain.setValueAtTime(this.osc1Gain.gain.value, now); // Hold current
        this.osc1Gain.gain.linearRampToValueAtTime(params.volume * 0.8, now + attackTime); // Quick ramp to new target peak
        this.osc1Gain.gain.setTargetAtTime(sustainLevel * params.volume, now + attackTime, decayTime / 3);
    }
    
    if(this.osc2) this.osc2.frequency.linearRampToValueAtTime(params.frequency * 2, now + rampTime);
    if(this.osc2Gain) {
        this.osc2Gain.gain.cancelScheduledValues(now);
        this.osc2Gain.gain.setValueAtTime(this.osc2Gain.gain.value, now);
        this.osc2Gain.gain.linearRampToValueAtTime((params.harmonyVolume ?? params.volume) * 0.5, now + attackTime);
        this.osc2Gain.gain.setTargetAtTime(sustainLevel * (params.harmonyVolume ?? params.volume) * 0.2, now + attackTime, decayTime / 2.5);
    }
     if(this.filter) this.filter.Q.linearRampToValueAtTime(0.5, now + rampTime); // Lower Q for plucks
  }

  public stopSound(): void {
    this.stopSoundInternal(0.5, true); // Default fade out, and update global isPlaying
  }

  private stopSoundInternal(fadeOutTime: number, setGlobalIsPlayingFalse: boolean): void {
    if (!this.audioCtx) {
      if (setGlobalIsPlayingFalse) {
        this.isPlaying = false;
        this.lastParams = null;
      }
      return;
    }
    
    // If not playing but a global stop is requested, ensure cleanup and state.
    if (!this.isPlaying && setGlobalIsPlayingFalse) {
        this.isPlaying = false;
        this.lastParams = null;
        this.cleanupOscillators();
        return;
    }
    // If not playing and it's a transitional stop, nothing to do.
    if (!this.isPlaying && !setGlobalIsPlayingFalse) {
        return;
    }

    const now = this.audioCtx.currentTime;

    [this.osc1Gain, this.osc2Gain, this.osc3Gain].forEach(gainNode => {
      if (gainNode) {
        gainNode.gain.cancelScheduledValues(now);
        gainNode.gain.setValueAtTime(gainNode.gain.value, now); // Ensure smooth ramp from current value
        gainNode.gain.linearRampToValueAtTime(0, now + fadeOutTime);
      }
    });
    // LFO gain also needs to be faded if it directly contributes to audible sound or modulation depth
    if (this.lfoGain) {
        this.lfoGain.gain.cancelScheduledValues(now);
        this.lfoGain.gain.setValueAtTime(this.lfoGain.gain.value, now);
        this.lfoGain.gain.linearRampToValueAtTime(0, now + fadeOutTime);
    }

    const stopTime = now + fadeOutTime + 0.01; // Stop slightly after gain reaches 0
    [this.osc1, this.osc2, this.osc3, this.lfo].forEach(oscNode => {
      if (oscNode) {
        try { oscNode.stop(stopTime); } catch (e) { /* already stopped */ }
      }
    });
    
    if (setGlobalIsPlayingFalse) {
      this.isPlaying = false;
      this.lastParams = null;
      // Schedule cleanup after fade out to ensure nodes are stopped before disconnecting
      setTimeout(() => {
        if (!this.isPlaying) { // Only cleanup if a new sound hasn't started in the meantime
            this.cleanupOscillators();
        }
      }, (fadeOutTime + 0.05) * 1000);
    }
    // If it's a transitional stop (setGlobalIsPlayingFalse is false),
    // cleanupOscillators() will be called by the subsequent startSound().
  }


  public calculateAudioParams(x: number, y: number, width: number, height: number, speed: number): AudioParameters {
    const normalizedX = x / width;
    const normalizedY = 1 - (y / height); // Invert Y: top is higher value

    const freqRange = Math.log2(MAX_FREQ / MIN_FREQ);
    const frequency = MIN_FREQ * Math.pow(2, normalizedX * freqRange);

    const volume = Math.max(0.01, Math.min(1, normalizedY)) * 0.8 + 0.2; 

    const normalizedSpeed = Math.min(1, speed / 50); 
    const filterCutoff = MIN_FILTER_FREQ + normalizedSpeed * (MAX_FILTER_FREQ - MIN_FILTER_FREQ);

    const harmonyVolume = Math.max(0, Math.min(1, normalizedY)) * 0.6 + 0.1;

    return { frequency, volume, filterCutoff, harmonyVolume };
  }
}

const audioService = new AudioService();
export default audioService;